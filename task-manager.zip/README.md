To run the project locally:

Unzip the file.

Run npm install to install dependencies.

Start the app using npm start.

Open http://localhost:3000 in your browser.




